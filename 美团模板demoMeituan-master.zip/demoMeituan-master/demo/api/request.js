//公用地址
let url = 'https://meituan.thexxdd.cn/api/'

//preference
let getpreference = `${url}forshop/getprefer`

//takeout附近商家
let wxshopurl = `${url}forshop/wxshop`

//筛选content
let startingUrl = `${url}forshop/starting`

//筛选多选
let multipleurl = `${url}forshop/multiple`

//搜索内容
let searchurl = `${url}forshop/search`

export {getpreference,wxshopurl,startingUrl,multipleurl,searchurl}