<template>
	<view class="title">
		附近商家
	</view>
</template>

<script>
</script>

<style scoped>
	.title {
		font-size: 36upx;
		height: 50upx;
		line-height: 50upx;
		margin-bottom: 10upx;
	}
</style>